<?php
/**
 * index.php
 * Página principal del sitio
 */

require_once 'config.php';
require_once 'funciones.php';

$titulo_pagina = 'Inicio - ' . APP_NAME;

// Obtener información
$config = obtener_config_sistema($mysqli);
$servicios = obtener_servicios($mysqli);
$barberos = obtener_barberos($mysqli);
$citas_proximas = [];
$proximas_citas = 0;

if ($usuario_logueado) {
    $citas_proximas = obtener_citas_usuario($usuario_id, $mysqli);
    $proximas_citas = count(array_filter($citas_proximas, fn($c) => ($c['estado'] === 'pendiente' || $c['estado'] === 'confirmada') && $c['fecha'] >= date('Y-m-d')));
}

// Capturar contenido
ob_start();
?>

<!-- HERO SECTION -->
<section class="hero mb-50" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 60px 20px; border-radius: 10px; margin-bottom: 40px;">
    <div class="row align-items-center">
        <div class="col-md-6">
            <h1 style="font-size: 42px; font-weight: bold; margin-bottom: 20px;">
                ✂️ Bienvenido a <?php echo $config['nombre_barberia']; ?>
            </h1>
            <p style="font-size: 18px; margin-bottom: 25px; opacity: 0.95;">
                La forma más fácil de reservar tu corte de barba. Elige barbero, servicio y hora en segundos.
            </p>
            <?php if ($usuario_logueado): ?>
                <a href="nueva_reserva.php" class="btn btn-light btn-lg" style="margin-right: 10px;">
                    <i class="bi bi-calendar-plus"></i> Reservar Cita
                </a>
                <a href="reservas.php" class="btn btn-secondary btn-lg">
                    <i class="bi bi-calendar-check"></i> Mis Reservas (<?php echo $proximas_citas; ?>)
                </a>
            <?php else: ?>
                <a href="login.php" class="btn btn-light btn-lg">
                    <i class="bi bi-box-arrow-in-right"></i> Inicia Sesión para Reservar
                </a>
            <?php endif; ?>
        </div>
        <div class="col-md-6 text-center">
            <i class="bi bi-scissors" style="font-size: 80px; opacity: 0.9;"></i>
        </div>
    </div>
</section>

<!-- INFORMACIÓN GENERAL -->
<div class="row mb-40">
    <div class="col-md-4 mb-3">
        <div class="card text-center">
            <div class="card-body">
                <i class="bi bi-clock text-primary" style="font-size: 32px; margin-bottom: 10px;"></i>
                <h5 class="card-title">Horarios</h5>
                <p class="card-text text-muted">
                    <strong><?php echo formatear_hora($config['horario_apertura']); ?></strong> - 
                    <strong><?php echo formatear_hora($config['horario_cierre']); ?></strong>
                </p>
            </div>
        </div>
    </div>
    
    <div class="col-md-4 mb-3">
        <div class="card text-center">
            <div class="card-body">
                <i class="bi bi-telephone text-success" style="font-size: 32px; margin-bottom: 10px;"></i>
                <h5 class="card-title">Contacto</h5>
                <p class="card-text text-muted">
                    <strong><?php echo $config['telefono_barberia']; ?></strong>
                </p>
            </div>
        </div>
    </div>
    
    <div class="col-md-4 mb-3">
        <div class="card text-center">
            <div class="card-body">
                <i class="bi bi-geo-alt text-danger" style="font-size: 32px; margin-bottom: 10px;"></i>
                <h5 class="card-title">Ubicación</h5>
                <p class="card-text text-muted">
                    <strong><?php echo $config['ciudad']; ?></strong>
                </p>
            </div>
        </div>
    </div>
</div>

<!-- SECCIÓN DE SERVICIOS -->
<h2 class="mb-30" style="font-weight: bold; color: #333;">
    <i class="bi bi-scissors"></i> Nuestros Servicios
</h2>

<div class="row mb-40">
    <?php foreach ($servicios as $servicio): ?>
    <div class="col-md-4 mb-3">
        <div class="card h-100">
            <div class="card-body">
                <h5 class="card-title" style="color: #667eea; font-weight: bold;">
                    <?php echo $servicio['nombre']; ?>
                </h5>
                <p class="card-text"><?php echo $servicio['descripcion']; ?></p>
                <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 15px;">
                    <span style="font-size: 18px; color: #764ba2; font-weight: bold;">
                        €<?php echo number_format($servicio['precio'], 2, ',', '.'); ?>
                    </span>
                    <span class="badge bg-secondary">
                        <i class="bi bi-clock"></i> <?php echo $servicio['duracion_minutos']; ?> min
                    </span>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
</div>

<!-- SECCIÓN DE BARBEROS -->
<h2 class="mb-30" style="font-weight: bold; color: #333;">
    <i class="bi bi-person-check"></i> Nuestro Equipo
</h2>

<div class="row mb-40">
    <?php foreach ($barberos as $barbero): ?>
    <div class="col-md-6 mb-3">
        <div class="card">
            <div class="card-body">
                <div style="display: flex; justify-content: space-between; align-items: start;">
                    <div>
                        <h5 class="card-title">
                            <i class="bi bi-person-fill" style="color: #667eea;"></i>
                            <?php echo $barbero['nombre'] . ' ' . $barbero['apellidos']; ?>
                        </h5>
                        <p class="card-text text-muted">
                            <i class="bi bi-briefcase"></i> <?php echo $barbero['especialidad']; ?>
                        </p>
                        <p class="card-text text-muted">
                            <i class="bi bi-award"></i> <?php echo $barbero['experiencia_anos']; ?> años de experiencia
                        </p>
                        <p class="card-text text-muted">
                            <i class="bi bi-clock-history"></i> 
                            <?php echo formatear_hora($barbero['horario_inicio']); ?> - 
                            <?php echo formatear_hora($barbero['horario_fin']); ?>
                        </p>
                        <p class="card-text text-muted">
                            <i class="bi bi-calendar"></i> <?php echo $barbero['dias_atiende']; ?>
                        </p>
                    </div>
                    <div style="font-size: 40px; opacity: 0.1;">✂️</div>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
</div>

<!-- SECCIÓN DE CITAS PRÓXIMAS (Solo si está logueado) -->
<?php if ($usuario_logueado && !empty($citas_proximas)): ?>
    <h2 class="mb-30" style="font-weight: bold; color: #333;">
        <i class="bi bi-calendar-event"></i> Mis Próximas Citas
    </h2>
    
    <div class="row mb-40">
        <?php 
        $mostradas = 0;
        foreach ($citas_proximas as $cita): 
            if (($cita['estado'] === 'pendiente' || $cita['estado'] === 'confirmada') && $cita['fecha'] >= date('Y-m-d') && $mostradas < 3):
                $mostradas++;
        ?>
        <div class="col-md-4 mb-3">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">
                        <?php echo $cita['servicio_nombre']; ?>
                    </h5>
                    <p class="card-text">
                        <strong>Barbero:</strong> <?php echo $cita['barbero_nombre'] . ' ' . $cita['barbero_apellidos']; ?>
                    </p>
                    <p class="card-text">
                        <strong>Fecha:</strong> <?php echo formatear_fecha($cita['fecha']); ?>
                    </p>
                    <p class="card-text">
                        <strong>Hora:</strong> <?php echo formatear_hora($cita['hora']); ?>
                    </p>
                    <p class="card-text">
                        <strong>Duración:</strong> <?php echo $cita['duracion_minutos']; ?> minutos
                    </p>
                    <div class="mt-20">
                        <span class="badge badge-estado-<?php echo $cita['estado']; ?>">
                            <i class="bi bi-circle-fill"></i> 
                            <?php echo ucfirst($cita['estado']); ?>
                        </span>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; endforeach; ?>
    </div>
<?php endif; ?>

<!-- CALL TO ACTION -->
<?php if ($usuario_logueado): ?>
    <section class="bg-light p-20 rounded text-center">
        <h3 style="margin-bottom: 15px; color: #333;">¿Listo para tu siguiente corte?</h3>
        <a href="nueva_reserva.php" class="btn btn-primary btn-lg">
            <i class="bi bi-calendar-plus"></i> Reservar Ahora
        </a>
    </section>
<?php else: ?>
    <section class="bg-light p-20 rounded text-center">
        <h3 style="margin-bottom: 15px; color: #333;">¿Aún no tienes cuenta?</h3>
        <p style="margin-bottom: 20px; color: #666;">Regístrate y disfruta de nuestros servicios</p>
        <a href="registro.php" class="btn btn-primary btn-lg" style="margin-right: 10px;">
            <i class="bi bi-person-plus"></i> Crear Cuenta
        </a>
        <a href="login.php" class="btn btn-secondary btn-lg">
            <i class="bi bi-box-arrow-in-right"></i> Iniciar Sesión
        </a>
    </section>
<?php endif; ?>

<?php
$contenido = ob_get_clean();
include 'plantilla.php';
?>
