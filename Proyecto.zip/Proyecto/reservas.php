<?php
/**
 * reservas.php
 * Ver mis reservas
 */

require_once 'config.php';
require_once 'funciones.php';

verificar_autenticacion();

$titulo_pagina = 'Mis Reservas - ' . APP_NAME;

// Obtener citas del usuario
$citas = obtener_citas_usuario($usuario_id, $mysqli);

// Procesar cancelación
if (isset($_GET['cancelar']) && isset($_GET['id_cita'])) {
    $id_cita = intval($_GET['id_cita']);
    
    // Verificar que la cita es del usuario
    $cita = obtener_cita($id_cita, $mysqli);
    if ($cita && $cita['ID_usuario'] == $usuario_id && $cita['estado'] !== 'cancelada') {
        // Verificar que falten al menos 24 horas
        $fecha_cita = strtotime($cita['fecha'] . ' ' . $cita['hora']);
        $tiempo_restante = $fecha_cita - time();
        $horas = $tiempo_restante / 3600;
        
        if ($horas >= 24) {
            $query = "UPDATE citas SET estado = 'cancelada' WHERE ID_cita = $id_cita";
            if ($mysqli->query($query)) {
                redirigir_con_mensaje('reservas.php', '✅ Cita cancelada correctamente.', 'success');
            }
        } else {
            redirigir_con_mensaje('reservas.php', '❌ No puedes cancelar una cita con menos de 24 horas de anticipación.', 'warning');
        }
    }
}

ob_start();
?>

<div class="row mb-30">
    <div class="col-md-12">
        <div class="d-flex justify-content-between align-items-center mb-20">
            <h1 class="mb-0">
                <i class="bi bi-calendar-check"></i> Mis Citas
            </h1>
            <a href="nueva_reserva.php" class="btn btn-primary">
                <i class="bi bi-plus-circle"></i> Nueva Reserva
            </a>
        </div>
    </div>
</div>

<?php if (empty($citas)): ?>
    <div class="no-data">
        <i class="bi bi-calendar-x" style="font-size: 64px; color: #ccc;"></i>
        <h4 class="mt-3">No tienes citas aún</h4>
        <p>¿Por qué no reservas una ahora?</p>
        <a href="nueva_reserva.php" class="btn btn-primary mt-3">
            <i class="bi bi-calendar-plus"></i> Reservar Cita
        </a>
    </div>
<?php else: ?>
    <!-- FICHAS DE CITAS -->
    <div class="row">
        <?php foreach ($citas as $cita): ?>
        <div class="col-md-6 mb-3">
            <div class="card" style="border-left: 4px solid <?php echo match($cita['estado']) { 'pendiente' => '#ffc107', 'confirmada' => '#28a745', 'cancelada' => '#dc3545', 'completada' => '#17a2b8', default => '#999' }; ?>">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-start mb-2">
                        <h5 class="card-title mb-0">
                            <?php echo $cita['servicio_nombre']; ?>
                        </h5>
                        <span class="badge badge-estado-<?php echo $cita['estado']; ?>">
                            <i class="bi bi-circle-fill"></i> 
                            <?php echo ucfirst($cita['estado']); ?>
                        </span>
                    </div>
                    
                    <div class="card-text mt-3">
                        <div class="mb-2">
                            <strong>👨‍💼 Barbero:</strong> 
                            <?php echo $cita['barbero_nombre'] . ' ' . $cita['barbero_apellidos']; ?>
                        </div>
                        
                        <div class="mb-2">
                            <strong>📅 Fecha:</strong> 
                            <?php echo formatear_fecha($cita['fecha']); ?>
                        </div>
                        
                        <div class="mb-2">
                            <strong>🕐 Hora:</strong> 
                            <?php echo formatear_hora($cita['hora']); ?>
                        </div>
                        
                        <div class="mb-2">
                            <strong>⏱️ Duración:</strong> 
                            <?php echo $cita['duracion_minutos']; ?> minutos
                        </div>
                        
                        <div class="mb-2">
                            <strong>💰 Precio:</strong> 
                            €<?php echo number_format($cita['precio_final'], 2, ',', '.'); ?>
                        </div>
                        
                        <?php if ($cita['notas_cliente']): ?>
                        <div class="mb-2 p-2 bg-light rounded" style="font-size: 13px;">
                            <strong>📝 Notas:</strong> <?php echo $cita['notas_cliente']; ?>
                        </div>
                        <?php endif; ?>
                    </div>
                    
                    <!-- ACCIONES -->
                    <div class="mt-3 d-flex gap-2">
                        <?php 
                        $fecha_cita = strtotime($cita['fecha'] . ' ' . $cita['hora']);
                        $tiempo_restante = $fecha_cita - time();
                        $horas = $tiempo_restante / 3600;
                        $es_proxima = $tiempo_restante > 0;
                        $puede_cancelar = $horas >= 24 && ($cita['estado'] === 'pendiente' || $cita['estado'] === 'confirmada');
                        ?>
                        
                        <?php if ($puede_cancelar): ?>
                            <a 
                                href="reservas.php?cancelar=1&id_cita=<?php echo $cita['ID_cita']; ?>" 
                                class="btn btn-sm btn-danger"
                                onclick="return confirm('¿Estás seguro de que quieres cancelar esta cita?');"
                            >
                                <i class="bi bi-x-circle"></i> Cancelar
                            </a>
                        <?php elseif (!$puede_cancelar && ($cita['estado'] === 'pendiente' || $cita['estado'] === 'confirmada')): ?>
                            <small class="text-muted">
                                <i class="bi bi-info-circle"></i> 
                                Se puede cancelar hasta 24h antes de la cita
                            </small>
                        <?php endif; ?>
                        
                        <?php if ($es_proxima && ($cita['estado'] === 'pendiente' || $cita['estado'] === 'confirmada')): ?>
                            <span class="badge bg-success ms-auto">
                                <i class="bi bi-hourglass-split"></i> 
                                Próxima en <?php echo floor($horas); ?>h
                            </span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>

    <!-- ESTADÍSTICAS -->
    <div class="row mt-40">
        <div class="col-md-3 mb-3">
            <div class="card text-center">
                <div class="card-body">
                    <h6 class="text-muted">Total de Citas</h6>
                    <h3 style="color: #667eea; font-weight: bold;" class="mb-0">
                        <?php echo count($citas); ?>
                    </h3>
                </div>
            </div>
        </div>
        
        <div class="col-md-3 mb-3">
            <div class="card text-center">
                <div class="card-body">
                    <h6 class="text-muted">Próximas</h6>
                    <h3 style="color: #28a745; font-weight: bold;" class="mb-0">
                        <?php echo count(array_filter($citas, fn($c) => strtotime($c['fecha']) >= time() && ($c['estado'] === 'pendiente' || $c['estado'] === 'confirmada'))); ?>
                    </h3>
                </div>
            </div>
        </div>
        
        <div class="col-md-3 mb-3">
            <div class="card text-center">
                <div class="card-body">
                    <h6 class="text-muted">Completadas</h6>
                    <h3 style="color: #17a2b8; font-weight: bold;" class="mb-0">
                        <?php echo count(array_filter($citas, fn($c) => $c['estado'] === 'completada')); ?>
                    </h3>
                </div>
            </div>
        </div>
        
        <div class="col-md-3 mb-3">
            <div class="card text-center">
                <div class="card-body">
                    <h6 class="text-muted">Gasto Total</h6>
                    <h3 style="color: #ffc107; font-weight: bold;" class="mb-0">
                        €<?php echo number_format(array_sum(array_column($citas, 'precio_final')), 2, ',', '.'); ?>
                    </h3>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>

<?php
$contenido = ob_get_clean();
include 'plantilla.php';
?>
