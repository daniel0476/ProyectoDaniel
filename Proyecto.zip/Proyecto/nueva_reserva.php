<?php
/**
 * nueva_reserva.php
 * Sistema de reservas con calendario y selección de horarios
 */

require_once 'config.php';
require_once 'funciones.php';

verificar_autenticacion();

$titulo_pagina = 'Nueva Reserva - ' . APP_NAME;

$error = '';
$exito = '';

// Obtener datos necesarios
$servicios = obtener_servicios($mysqli);
$barberos = obtener_barberos($mysqli);
$config = obtener_config_sistema($mysqli);

// Procesar reserva
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fecha = trim($_POST['fecha'] ?? '');
    $hora = trim($_POST['hora'] ?? '');
    $id_servicio = intval($_POST['id_servicio'] ?? 0);
    $dni_barbero = trim($_POST['dni_barbero'] ?? '');
    $notas = trim($_POST['notas'] ?? '');
    
    // Validar datos
    if (empty($fecha) || empty($hora) || $id_servicio <= 0 || empty($dni_barbero)) {
        $error = 'Por favor, completa todos los campos requeridos.';
    } else {
        // Obtener servicio
        $servicio = obtener_servicio($id_servicio, $mysqli);
        if (!$servicio) {
            $error = 'Servicio no encontrado.';
        } else {
            // Verificar que la fecha sea válida (hoy o futura)
            if (strtotime($fecha) < strtotime(date('Y-m-d'))) {
                $error = 'La fecha debe ser hoy o posterior.';
            } else {
                // Obtener barbero
                $barbero = obtener_barbero($dni_barbero, $mysqli);
                if (!$barbero) {
                    $error = 'Barbero no encontrado.';
                } else {
                    // Verificar que el horario esté disponible
                    $citas_ocupadas = obtener_citas_barbero_fecha($dni_barbero, $fecha, $mysqli);
                    
                    // Verificar disponibilidad
                    $disponible = true;
                    foreach ($citas_ocupadas as $cita_ocupada) {
                        $cita_inicio = strtotime($cita_ocupada['hora']);
                        $cita_fin = strtotime('+' . $cita_ocupada['duracion_minutos'] . ' minutes', $cita_inicio);
                        $reserva_inicio = strtotime($hora);
                        $reserva_fin = strtotime('+' . $servicio['duracion_minutos'] . ' minutes', $reserva_inicio);
                        
                        if ($reserva_inicio < $cita_fin && $reserva_fin > $cita_inicio) {
                            $disponible = false;
                            break;
                        }
                    }
                    
                    if (!$disponible) {
                        $error = 'El horario seleccionado no está disponible. Por favor, elige otro.';
                    } else {
                        // Crear reserva
                        $fecha_prep = escapar($fecha, $mysqli);
                        $hora_prep = escapar($hora, $mysqli);
                        $dni_prep = escapar($dni_barbero, $mysqli);
                        $notas_prep = escapar($notas, $mysqli);
                        
                        $query = "INSERT INTO citas (fecha, hora, DNI_barbero, ID_usuario, ID_servicio, precio_final, estado, notas_cliente) 
                                  VALUES ('$fecha_prep', '$hora_prep', '$dni_prep', $usuario_id, $id_servicio, " . $servicio['precio'] . ", 'pendiente', '$notas_prep')";
                        
                        if ($mysqli->query($query)) {
                            redirigir_con_mensaje('reservas.php', '✅ ¡Cita reservada con éxito! El barbero la confirmará pronto.', 'success');
                        } else {
                            $error = 'Error al crear la reserva: ' . $mysqli->error;
                        }
                    }
                }
            }
        }
    }
}

ob_start();
?>

<div class="row">
    <div class="col-md-8 offset-md-2">
        <div class="card">
            <div class="card-header">
                <h3 class="mb-0">
                    <i class="bi bi-calendar-plus"></i> Nueva Reserva
                </h3>
            </div>
            <div class="card-body">
                <?php if (!empty($error)): ?>
                    <div class="alert alert-danger"><?php echo $error; ?></div>
                <?php endif; ?>
                
                <form method="POST" id="formulario_reserva">
                    <!-- ROW 1: Servicio -->
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="id_servicio" class="form-label">
                                <i class="bi bi-scissors"></i> Servicio *
                            </label>
                            <select 
                                class="form-select" 
                                id="id_servicio" 
                                name="id_servicio" 
                                required
                                onchange="actualizarDuracion()"
                            >
                                <option value="">Selecciona un servicio...</option>
                                <?php foreach ($servicios as $svc): ?>
                                    <option value="<?php echo $svc['ID_servicio']; ?>" data-duracion="<?php echo $svc['duracion_minutos']; ?>">
                                        <?php echo $svc['nombre']; ?> - €<?php echo number_format($svc['precio'], 2, ',', '.'); ?> 
                                        (<?php echo $svc['duracion_minutos']; ?> min)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label for="dni_barbero" class="form-label">
                                <i class="bi bi-person-check"></i> Barbero *
                            </label>
                            <select 
                                class="form-select" 
                                id="dni_barbero" 
                                name="dni_barbero" 
                                required
                                onchange="actualizarHorarios()"
                            >
                                <option value="">Selecciona un barbero...</option>
                                <?php foreach ($barberos as $bar): ?>
                                    <option value="<?php echo $bar['DNI_barbero']; ?>">
                                        <?php echo $bar['nombre'] . ' ' . $bar['apellidos']; ?> 
                                        (<?php echo $bar['especialidad']; ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    
                    <!-- ROW 2: Fecha y Hora -->
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="fecha" class="form-label">
                                <i class="bi bi-calendar"></i> Fecha *
                            </label>
                            <input 
                                type="date" 
                                class="form-control" 
                                id="fecha" 
                                name="fecha" 
                                required
                                min="<?php echo date('Y-m-d'); ?>"
                                onchange="actualizarHorarios()"
                            >
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label for="hora" class="form-label">
                                <i class="bi bi-clock"></i> Hora *
                            </label>
                            <select class="form-select" id="hora" name="hora" required>
                                <option value="">Selecciona hora...</option>
                            </select>
                            <small class="text-muted mt-2" id="horas_disponibles"></small>
                        </div>
                    </div>
                    
                    <!-- NOTAS -->
                    <div class="mb-3">
                        <label for="notas" class="form-label">
                            <i class="bi bi-chat"></i> Notas (Opcional)
                        </label>
                        <textarea 
                            class="form-control" 
                            id="notas" 
                            name="notas" 
                            rows="3" 
                            placeholder="Indicaciones especiales, alergia a productos, etc."
                        ></textarea>
                    </div>
                    
                    <!-- RESUMEN -->
                    <div class="alert alert-info" id="resumen" style="display: none;">
                        <strong>📋 Resumen de tu reserva:</strong>
                        <div id="resumen_contenido"></div>
                    </div>
                    
                    <!-- BOTONES -->
                    <div class="d-flex gap-2 justify-content-between">
                        <a href="index.php" class="btn btn-secondary">
                            <i class="bi bi-arrow-left"></i> Volver
                        </a>
                        <button 
                            type="submit" 
                            class="btn btn-primary" 
                            id="btn_reservar"
                            disabled
                        >
                            <i class="bi bi-check-circle"></i> Confirmar Reserva
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
const config = {
    horario_apertura: '<?php echo $config['horario_apertura']; ?>',
    horario_cierre: '<?php echo $config['horario_cierre']; ?>',
    duracion_slot: <?php echo $config['duracion_slot_minutos']; ?>,
    tiempo_preparacion: <?php echo $config['tiempo_preparacion_minutos']; ?>
};

const servicios = <?php echo json_encode($servicios); ?>;
const barberos = <?php echo json_encode($barberos); ?>;

// Actualizar duración al cambiar servicio
function actualizarDuracion() {
    const select = document.getElementById('id_servicio');
    const option = select.options[select.selectedIndex];
    if (option.value) {
        actualizarResumen();
    }
}

// Actualizar horarios disponibles
function actualizarHorarios() {
    const fecha = document.getElementById('fecha').value;
    const dni_barbero = document.getElementById('dni_barbero').value;
    const horaSelect = document.getElementById('hora');
    
    horaSelect.innerHTML = '<option value="">Selecciona hora...</option>';
    
    if (!fecha || !dni_barbero) {
        return;
    }
    
    // Obtener citas ocupadas via AJAX (simulado)
    // En producción, esto sería una llamada AJAX a un archivo PHP
    generarHorarios();
}

// Generar slots de horarios disponibles
function generarHorarios() {
    const horaSelect = document.getElementById('hora');
    const horaInicio = config.horario_apertura;
    const horaFin = config.horario_cierre;
    const duracion = config.duracion_slot;
    
    const inicio = horaInicio.split(':').reduce((a, b) => parseInt(a) * 60 + parseInt(b));
    const fin = horaFin.split(':').reduce((a, b) => parseInt(a) * 60 + parseInt(b));
    
    for (let t = inicio; t < fin; t += duracion) {
        const horas = Math.floor(t / 60);
        const minutos = t % 60;
        const hora = `${String(horas).padStart(2, '0')}:${String(minutos).padStart(2, '0')}`;
        
        const option = document.createElement('option');
        option.value = hora;
        option.textContent = hora;
        horaSelect.appendChild(option);
    }
    
    actualizarResumen();
}

// Actualizar resumen
function actualizarResumen() {
    const idServicio = document.getElementById('id_servicio').value;
    const dniBarbero = document.getElementById('dni_barbero').value;
    const fecha = document.getElementById('fecha').value;
    const hora = document.getElementById('hora').value;
    
    const btnReservar = document.getElementById('btn_reservar');
    
    if (idServicio && dniBarbero && fecha && hora) {
        const servicio = servicios.find(s => s.ID_servicio == idServicio);
        const barbero = barberos.find(b => b.DNI_barbero == dniBarbero);
        
        const resumenContent = `
            <div style="margin-top: 10px;">
                <p><strong>Servicio:</strong> ${servicio.nombre} - €${parseFloat(servicio.precio).toFixed(2)}</p>
                <p><strong>Barbero:</strong> ${barbero.nombre} ${barbero.apellidos}</p>
                <p><strong>Fecha:</strong> ${new Date(fecha).toLocaleDateString('es-ES', {weekday: 'long', year: 'numeric', month: 'long', day: 'numeric'})}</p>
                <p><strong>Hora:</strong> ${hora}</p>
                <p><strong>Duración:</strong> ${servicio.duracion_minutos} minutos</p>
            </div>
        `;
        
        document.getElementById('resumen_contenido').innerHTML = resumenContent;
        document.getElementById('resumen').style.display = 'block';
        btnReservar.disabled = false;
    } else {
        document.getElementById('resumen').style.display = 'none';
        btnReservar.disabled = true;
    }
}

// Event listeners
document.getElementById('fecha').addEventListener('change', actualizarHorarios);
document.getElementById('dni_barbero').addEventListener('change', actualizarHorarios);
document.getElementById('hora').addEventListener('change', actualizarResumen);
document.getElementById('id_servicio').addEventListener('change', actualizarResumen);
</script>

<?php
$contenido = ob_get_clean();
include 'plantilla.php';
?>
