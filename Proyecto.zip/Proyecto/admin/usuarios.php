<?php
/**
 * admin/usuarios.php
 * CRUD completo de usuarios
 */

require_once '../config.php';
require_once '../funciones.php';

verificar_autenticacion();
verificar_admin();

$titulo_pagina = 'Gestión de Usuarios - ' . APP_NAME;

$error = '';
$exito = '';

// Procesar acciones
if (isset($_GET['eliminar'])) {
    $id = intval($_GET['id'] ?? 0);
    if ($id > 0 && $id !== $usuario_id) {
        $query = "UPDATE usuarios SET activo = 0 WHERE ID_usuario = $id";
        if ($mysqli->query($query)) {
            $exito = '✅ Usuario eliminado correctamente.';
        }
    }
}

// Procesar cambio de rol
if (isset($_GET['cambiar_rol'])) {
    $id = intval($_GET['id'] ?? 0);
    $rol = trim($_GET['rol'] ?? '');
    
    if ($id > 0 && in_array($rol, ['cliente', 'admin']) && $id !== $usuario_id) {
        $query = "UPDATE usuarios SET rol = '$rol' WHERE ID_usuario = $id";
        if ($mysqli->query($query)) {
            $exito = '✅ Rol actualizado correctamente.';
        }
    }
}

// Obtener todos los usuarios
$query = "SELECT * FROM usuarios WHERE rol = 'cliente' ORDER BY nombre";
$usuarios = $mysqli->query($query)->fetch_all(MYSQLI_ASSOC);

ob_start();
?>

<div class="mb-30">
    <h1 class="mb-20">
        <i class="bi bi-people"></i> Gestión de Usuarios
    </h1>
    <p class="text-muted">Total de clientes registrados: <strong><?php echo count($usuarios); ?></strong></p>
</div>

<?php if (!empty($error)): ?>
    <div class="alert alert-danger"><?php echo $error; ?></div>
<?php endif; ?>

<?php if (!empty($exito)): ?>
    <div class="alert alert-success"><?php echo $exito; ?></div>
<?php endif; ?>

<!-- TABLA DE USUARIOS -->
<div class="card">
    <div class="card-body">
        <?php if (empty($usuarios)): ?>
            <div class="no-data">
                <i class="bi bi-person-x" style="font-size: 48px; color: #ccc;"></i>
                <h4 class="mt-3">No hay usuarios registrados</h4>
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nombre</th>
                            <th>Email</th>
                            <th>Teléfono</th>
                            <th>Citas</th>
                            <th>Registro</th>
                            <th>Estado</th>
                            <th>Rol</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($usuarios as $u): ?>
                            <?php 
                            // Obtener cantidad de citas
                            $query_citas = "SELECT COUNT(*) as total FROM citas WHERE ID_usuario = " . $u['ID_usuario'];
                            $citas_count = $mysqli->query($query_citas)->fetch_assoc()['total'];
                            ?>
                        <tr>
                            <td><small class="text-muted">#<?php echo $u['ID_usuario']; ?></small></td>
                            <td>
                                <strong><?php echo $u['nombre'] . ' ' . $u['apellidos']; ?></strong>
                            </td>
                            <td><?php echo $u['email']; ?></td>
                            <td><?php echo $u['telefono'] ?? '-'; ?></td>
                            <td>
                                <span class="badge bg-secondary"><?php echo $citas_count; ?></span>
                            </td>
                            <td>
                                <small class="text-muted"><?php echo date('d/m/Y', strtotime($u['fecha_registro'])); ?></small>
                            </td>
                            <td>
                                <?php if ($u['activo']): ?>
                                    <span class="badge bg-success"><i class="bi bi-check-circle"></i> Activo</span>
                                <?php else: ?>
                                    <span class="badge bg-danger"><i class="bi bi-x-circle"></i> Inactivo</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <select class="form-select form-select-sm" onchange="cambiarRol(<?php echo $u['ID_usuario']; ?>, this.value)" style="max-width: 120px;">
                                    <option value="cliente" <?php echo $u['rol'] === 'cliente' ? 'selected' : ''; ?>>Cliente</option>
                                    <option value="admin" <?php echo $u['rol'] === 'admin' ? 'selected' : ''; ?>>Admin</option>
                                </select>
                            </td>
                            <td>
                                <a href="#" class="btn btn-sm btn-info" data-bs-toggle="modal" data-bs-target="#modalDetalles_<?php echo $u['ID_usuario']; ?>">
                                    <i class="bi bi-eye"></i> Ver
                                </a>
                                <a href="usuarios.php?eliminar=1&id=<?php echo $u['ID_usuario']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('¿Estás seguro?');">
                                    <i class="bi bi-trash"></i> Eliminar
                                </a>
                            </td>
                        </tr>
                        
                        <!-- MODAL DETALLES -->
                        <div class="modal fade" id="modalDetalles_<?php echo $u['ID_usuario']; ?>" tabindex="-1">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title">Detalles del Usuario</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                    </div>
                                    <div class="modal-body">
                                        <p><strong>ID:</strong> <?php echo $u['ID_usuario']; ?></p>
                                        <p><strong>Nombre:</strong> <?php echo $u['nombre'] . ' ' . $u['apellidos']; ?></p>
                                        <p><strong>Email:</strong> <?php echo $u['email']; ?></p>
                                        <p><strong>Teléfono:</strong> <?php echo $u['telefono'] ?? '-'; ?></p>
                                        <p><strong>Total de Citas:</strong> <?php echo $citas_count; ?></p>
                                        <p><strong>Registered:</strong> <?php echo formatear_fecha($u['fecha_registro']); ?></p>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<div class="mt-3">
    <a href="dashboard.php" class="btn btn-secondary">
        <i class="bi bi-arrow-left"></i> Volver al Dashboard
    </a>
</div>

<script>
function cambiarRol(id, rol) {
    if (confirm(`¿Cambiar rol a ${rol}?`)) {
        window.location = `usuarios.php?cambiar_rol=1&id=${id}&rol=${rol}`;
    }
}
</script>

<?php
$contenido = ob_get_clean();
include '../plantilla.php';
?>
