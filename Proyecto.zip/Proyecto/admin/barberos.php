<?php
/**
 * admin/barberos.php
 * CRUD de barberos
 */

require_once '../config.php';
require_once '../funciones.php';

verificar_autenticacion();
verificar_admin();

$titulo_pagina = 'Gestión de Barberos - ' . APP_NAME;

$error = '';
$exito = '';

// Procesar formulario
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $dni = trim($_POST['dni'] ?? '');
    $nombre = trim($_POST['nombre'] ?? '');
    $apellidos = trim($_POST['apellidos'] ?? '');
    $telefono = trim($_POST['telefono'] ?? '');
    $especialidad = trim($_POST['especialidad'] ?? '');
    $experiencia_anos = intval($_POST['experiencia_anos'] ?? 1);
    $horario_inicio = trim($_POST['horario_inicio'] ?? '09:00');
    $horario_fin = trim($_POST['horario_fin'] ?? '18:00');
    $dias_atiende = trim($_POST['dias_atiende'] ?? 'Lun-Vie');
    
    if (empty($dni) || empty($nombre) || empty($apellidos)) {
        $error = 'Por favor completa los campos obligatorios.';
    } else {
        // Verificar si existe
        $check = $mysqli->query("SELECT DNI_barbero FROM barberos WHERE DNI_barbero = '$dni'");
        
        if ($check->num_rows > 0) {
            // Actualizar
            $query = "UPDATE barberos SET nombre = '$nombre', apellidos = '$apellidos', telefono = '$telefono',
                     especialidad = '$especialidad', experiencia_anos = $experiencia_anos,
                     horario_inicio = '$horario_inicio', horario_fin = '$horario_fin', dias_atiende = '$dias_atiende'
                     WHERE DNI_barbero = '$dni'";
            $exito = '✅ Barbero actualizado correctamente.';
        } else {
            // Crear nuevo
            $query = "INSERT INTO barberos (DNI_barbero, nombre, apellidos, telefono, especialidad, experiencia_anos, horario_inicio, horario_fin, dias_atiende)
                     VALUES ('$dni', '$nombre', '$apellidos', '$telefono', '$especialidad', $experiencia_anos, '$horario_inicio', '$horario_fin', '$dias_atiende')";
            $exito = '✅ Barbero creado correctamente.';
        }
        
        if ($mysqli->query($query)) {
            $_POST = [];
        } else {
            $error = 'Error: ' . $mysqli->error;
        }
    }
}

// Procesar eliminación
if (isset($_GET['eliminar'])) {
    $dni = trim($_GET['dni'] ?? '');
    $query = "UPDATE barberos SET activo = 0 WHERE DNI_barbero = '$dni'";
    if ($mysqli->query($query)) {
        $exito = '✅ Barbero eliminado correctamente.';
    }
}

// Obtener barberos
$barberos = $mysqli->query("SELECT * FROM barberos WHERE activo = 1 ORDER BY nombre")->fetch_all(MYSQLI_ASSOC);

ob_start();
?>

<div class="row mb-30">
    <div class="col-md-6">
        <h1 class="mb-0">
            <i class="bi bi-person-badge"></i> Gestión de Barberos
        </h1>
    </div>
    <div class="col-md-6 text-end">
        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalBarbero">
            <i class="bi bi-plus-circle"></i> Nuevo Barbero
        </button>
    </div>
</div>

<?php if (!empty($error)): ?>
    <div class="alert alert-danger"><?php echo $error; ?></div>
<?php endif; ?>

<?php if (!empty($exito)): ?>
    <div class="alert alert-success"><?php echo $exito; ?></div>
<?php endif; ?>

<!-- LISTA DE BARBEROS -->
<div class="row">
    <?php foreach ($barberos as $barbero): ?>
    <div class="col-md-6 mb-3">
        <div class="card">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-start mb-2">
                    <h5 class="card-title mb-0">
                        <?php echo $barbero['nombre'] . ' ' . $barbero['apellidos']; ?>
                    </h5>
                    <span class="badge bg-secondary"><?php echo $barbero['dni']; ?></span>
                </div>
                
                <p class="card-text text-muted mb-2">
                    <i class="bi bi-briefcase"></i> <?php echo $barbero['especialidad']; ?>
                </p>
                
                <div class="mb-2">
                    <small><strong>Teléfono:</strong> <?php echo $barbero['telefono'] ?? '-'; ?></small><br>
                    <small><strong>Experiencia:</strong> <?php echo $barbero['experiencia_anos']; ?> años</small><br>
                    <small><strong>Horario:</strong> <?php echo formatear_hora($barbero['horario_inicio']); ?> - <?php echo formatear_hora($barbero['horario_fin']); ?></small><br>
                    <small><strong>Atiende:</strong> <?php echo $barbero['dias_atiende']; ?></small>
                </div>
                
                <div class="mt-3 d-flex gap-2">
                    <button class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#modalBarbero" onclick="cargarBarbero('<?php echo htmlspecialchars(json_encode($barbero)); ?>')">
                        <i class="bi bi-pencil"></i> Editar
                    </button>
                    <a href="barberos.php?eliminar=1&dni=<?php echo urlencode($barbero['DNI_barbero']); ?>" class="btn btn-sm btn-danger" onclick="return confirm('¿Seguro?');">
                        <i class="bi bi-trash"></i> Eliminar
                    </a>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
</div>

<!-- MODAL FORMULARIO -->
<div class="modal fade" id="modalBarbero" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="tituloModal">Nuevo Barbero</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="dni" class="form-label">DNI *</label>
                        <input type="text" class="form-control" id="dni" name="dni" required>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="nombre" class="form-label">Nombre *</label>
                            <input type="text" class="form-control" id="nombre" name="nombre" required>
                        </div>
                        <div class="col-md-6">
                            <label for="apellidos" class="form-label">Apellidos *</label>
                            <input type="text" class="form-control" id="apellidos" name="apellidos" required>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="telefono" class="form-label">Teléfono</label>
                        <input type="tel" class="form-control" id="telefono" name="telefono">
                    </div>
                    
                    <div class="mb-3">
                        <label for="especialidad" class="form-label">Especialidad</label>
                        <input type="text" class="form-control" id="especialidad" name="especialidad" placeholder="Ej: Cortes degradados">
                    </div>
                    
                    <div class="mb-3">
                        <label for="experiencia_anos" class="form-label">Años de Experiencia</label>
                        <input type="number" class="form-control" id="experiencia_anos" name="experiencia_anos" value="1" min="0">
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="horario_inicio" class="form-label">Horario Inicio</label>
                            <input type="time" class="form-control" id="horario_inicio" name="horario_inicio" value="09:00">
                        </div>
                        <div class="col-md-6">
                            <label for="horario_fin" class="form-label">Horario Fin</label>
                            <input type="time" class="form-control" id="horario_fin" name="horario_fin" value="18:00">
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="dias_atiende" class="form-label">Días que Atiende</label>
                        <input type="text" class="form-control" id="dias_atiende" name="dias_atiende" placeholder="Ej: Lun-Vie">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Guardar</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="mt-3">
    <a href="dashboard.php" class="btn btn-secondary">
        <i class="bi bi-arrow-left"></i> Volver
    </a>
</div>

<script>
function cargarBarbero(datos) {
    const barbero = JSON.parse(datos);
    document.getElementById('dni').value = barbero.DNI_barbero;
    document.getElementById('nombre').value = barbero.nombre;
    document.getElementById('apellidos').value = barbero.apellidos;
    document.getElementById('telefono').value = barbero.telefono || '';
    document.getElementById('especialidad').value = barbero.especialidad || '';
    document.getElementById('experiencia_anos').value = barbero.experiencia_anos;
    document.getElementById('horario_inicio').value = barbero.horario_inicio;
    document.getElementById('horario_fin').value = barbero.horario_fin;
    document.getElementById('dias_atiende').value = barbero.dias_atiende;
    document.getElementById('tituloModal').textContent = 'Editar Barbero';
}
</script>

<?php
$contenido = ob_get_clean();
include '../plantilla.php';
?>
