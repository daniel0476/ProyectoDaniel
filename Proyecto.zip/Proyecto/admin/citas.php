<?php
/**
 * admin/citas.php
 * Gestión de citas
 */

require_once '../config.php';
require_once '../funciones.php';

verificar_autenticacion();
verificar_admin();

$titulo_pagina = 'Gestión de Citas - ' . APP_NAME;

$filtro_estado = trim($_GET['estado'] ?? '');
$filtro_fecha = trim($_GET['fecha'] ?? '');

// Procesar cambio de estado
if (isset($_GET['cambiar_estado'])) {
    $id = intval($_GET['id'] ?? 0);
    $estado = trim($_GET['nuevo_estado'] ?? '');
    
    if ($id > 0 && in_array($estado, ['pendiente', 'confirmada', 'completada', 'cancelada'])) {
        $query = "UPDATE citas SET estado = '$estado' WHERE ID_cita = $id";
        $mysqli->query($query);
    }
}

// Construir query con filtros
$query = "SELECT c.*, 
         u.nombre as cliente_nombre, u.email as cliente_email, u.telefono as cliente_telefono,
         b.nombre as barbero_nombre, b.apellidos as barbero_apellidos,
         s.nombre as servicio_nombre, s.duracion_minutos
         FROM citas c
         LEFT JOIN usuarios u ON c.ID_usuario = u.ID_usuario
         LEFT JOIN barberos b ON c.DNI_barbero = b.DNI_barbero
         LEFT JOIN servicios s ON c.ID_servicio = s.ID_servicio
         WHERE 1=1";

if (!empty($filtro_estado)) {
    $filtro_estado = escapar($filtro_estado, $mysqli);
    $query .= " AND c.estado = '$filtro_estado'";
}

if (!empty($filtro_fecha)) {
    $filtro_fecha = escapar($filtro_fecha, $mysqli);
    $query .= " AND c.fecha = '$filtro_fecha'";
}

$query .= " ORDER BY c.fecha DESC, c.hora DESC";

$citas = $mysqli->query($query)->fetch_all(MYSQLI_ASSOC);

ob_start();
?>

<div class="row mb-30">
    <div class="col-md-8">
        <h1 class="mb-0"><i class="bi bi-calendar-check"></i> Gestión de Citas</h1>
    </div>
</div>

<!-- FILTROS -->
<div class="card mb-3">
    <div class="card-body">
        <form method="GET" action="citas.php" class="row g-3">
            <div class="col-md-4">
                <label for="estado" class="form-label">Estado</label>
                <select class="form-select" id="estado" name="estado">
                    <option value="">Todos</option>
                    <option value="pendiente" <?php echo $filtro_estado === 'pendiente' ? 'selected' : ''; ?>>Pendiente</option>
                    <option value="confirmada" <?php echo $filtro_estado === 'confirmada' ? 'selected' : ''; ?>>Confirmada</option>
                    <option value="completada" <?php echo $filtro_estado === 'completada' ? 'selected' : ''; ?>>Completada</option>
                    <option value="cancelada" <?php echo $filtro_estado === 'cancelada' ? 'selected' : ''; ?>>Cancelada</option>
                </select>
            </div>
            
            <div class="col-md-4">
                <label for="fecha" class="form-label">Fecha</label>
                <input type="date" class="form-control" id="fecha" name="fecha" value="<?php echo $filtro_fecha; ?>">
            </div>
            
            <div class="col-md-4">
                <label class="form-label">&nbsp;</label>
                <div>
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="bi bi-search"></i> Filtrar
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>

<!-- TABLA -->
<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-sm">
                <thead>
                    <tr>
                        <th>Fecha/Hora</th>
                        <th>Cliente</th>
                        <th>Barbero</th>
                        <th>Servicio</th>
                        <th>Precio</th>
                        <th>Estado</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($citas as $cita): ?>
                    <tr>
                        <td>
                            <strong><?php echo date('d/m/Y', strtotime($cita['fecha'])); ?></strong><br>
                            <small><?php echo formatear_hora($cita['hora']); ?></small>
                        </td>
                        <td>
                            <strong><?php echo $cita['cliente_nombre'] ?? 'N/A'; ?></strong><br>
                            <small><?php echo $cita['cliente_email'] ?? ''; ?></small>
                        </td>
                        <td><?php echo $cita['barbero_nombre'] . ' ' . ($cita['barbero_apellidos'] ?? ''); ?></td>
                        <td><?php echo $cita['servicio_nombre']; ?></td>
                        <td>€<?php echo number_format($cita['precio_final'], 2); ?></td>
                        <td>
                            <select class="form-select form-select-sm" onchange="cambiarEstado(<?php echo $cita['ID_cita']; ?>, this.value)" style="max-width: 120px;">
                                <option value="pendiente" <?php echo $cita['estado'] === 'pendiente' ? 'selected' : ''; ?>>Pendiente</option>
                                <option value="confirmada" <?php echo $cita['estado'] === 'confirmada' ? 'selected' : ''; ?>>Confirmada</option>
                                <option value="completada" <?php echo $cita['estado'] === 'completada' ? 'selected' : ''; ?>>Completada</option>
                                <option value="cancelada" <?php echo $cita['estado'] === 'cancelada' ? 'selected' : ''; ?>>Cancelada</option>
                            </select>
                        </td>
                        <td>
                            <button class="btn btn-sm btn-info" data-bs-toggle="modal" data-bs-target="#modalDetalles_<?php echo $cita['ID_cita']; ?>">
                                <i class="bi bi-eye"></i>
                            </button>
                        </td>
                    </tr>
                    
                    <!-- MODAL DETALLES -->
                    <div class="modal fade" id="modalDetalles_<?php echo $cita['ID_cita']; ?>" tabindex="-1">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title">Detalles de la Cita</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                </div>
                                <div class="modal-body">
                                    <p><strong>Cliente:</strong> <?php echo $cita['cliente_nombre']; ?></p>
                                    <p><strong>Email:</strong> <?php echo $cita['cliente_email']; ?></p>
                                    <p><strong>Teléfono:</strong> <?php echo $cita['cliente_telefono'] ?? '-'; ?></p>
                                    <hr>
                                    <p><strong>Barbero:</strong> <?php echo $cita['barbero_nombre'] . ' ' . $cita['barbero_apellidos']; ?></p>
                                    <p><strong>Servicio:</strong> <?php echo $cita['servicio_nombre']; ?></p>
                                    <p><strong>Fecha:</strong> <?php echo formatear_fecha($cita['fecha']); ?></p>
                                    <p><strong>Hora:</strong> <?php echo formatear_hora($cita['hora']); ?></p>
                                    <p><strong>Duración:</strong> <?php echo $cita['duracion_minutos']; ?> minutos</p>
                                    <p><strong>Precio:</strong> €<?php echo number_format($cita['precio_final'], 2); ?></p>
                                    <?php if ($cita['notas_cliente']): ?>
                                        <p><strong>Notas del cliente:</strong><br><?php echo $cita['notas_cliente']; ?></p>
                                    <?php endif; ?>
                                    <?php if ($cita['notas_admin']): ?>
                                        <p><strong>Notas del admin:</strong><br><?php echo $cita['notas_admin']; ?></p>
                                    <?php endif; ?>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="mt-3">
    <a href="dashboard.php" class="btn btn-secondary">
        <i class="bi bi-arrow-left"></i> Volver
    </a>
</div>

<script>
function cambiarEstado(id, estado) {
    if (confirm(`¿Cambiar estado a ${estado}?`)) {
        window.location = `citas.php?cambiar_estado=1&id=${id}&nuevo_estado=${estado}`;
    }
}
</script>

<?php
$contenido = ob_get_clean();
include '../plantilla.php';
?>
