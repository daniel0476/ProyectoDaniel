<?php
/**
 * plantilla.php
 * Plantilla base del sitio con header y footer
 */
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $titulo_pagina ?? APP_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/flatpickr@4.6.13/dist/flatpickr.min.css" rel="stylesheet">
    <style>
        :root {
            --primary: #667eea;
            --secondary: #764ba2;
            --success: #28a745;
            --warning: #ffc107;
            --danger: #dc3545;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }
        
        /* HEADER */
        header {
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            color: white;
            padding: 15px 0;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            position: sticky;
            top: 0;
            z-index: 100;
        }
        
        .navbar-brand {
            font-size: 24px;
            font-weight: bold;
            margin-right: 30px;
        }
        
        .navbar-brand i {
            margin-right: 10px;
        }
        
        .nav-link {
            color: rgba(255, 255, 255, 0.9) !important;
            margin: 0 10px;
            transition: all 0.3s;
        }
        
        .nav-link:hover {
            color: white !important;
            transform: translateY(-2px);
        }
        
        .nav-link.active {
            color: white !important;
            border-bottom: 3px solid white;
            padding-bottom: 5px;
        }
        
        .user-menu {
            display: flex;
            align-items: center;
            gap: 20px;
        }
        
        .user-info {
            color: rgba(255, 255, 255, 0.9);
            font-size: 14px;
        }
        
        .user-info strong {
            color: white;
        }
        
        .btn-logout {
            background: rgba(255, 255, 255, 0.2);
            border: 1px solid white;
            color: white;
            padding: 6px 15px;
            border-radius: 5px;
            text-decoration: none;
            transition: all 0.3s;
        }
        
        .btn-logout:hover {
            background: white;
            color: var(--primary);
        }
        
        /* MAIN CONTENT */
        main {
            flex: 1;
            padding: 30px 20px;
        }
        
        .container {
            max-width: 1200px;
        }
        
        /* CARDS */
        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.08);
            transition: all 0.3s;
            margin-bottom: 20px;
        }
        
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.12);
        }
        
        .card-header {
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            color: white;
            border: none;
            border-radius: 10px 10px 0 0;
            padding: 20px;
        }
        
        .card-body {
            padding: 25px;
        }
        
        /* BUTTONS */
        .btn {
            border-radius: 5px;
            padding: 8px 20px;
            font-weight: 600;
            transition: all 0.3s;
            border: none;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            color: white;
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
        }
        
        .btn-secondary {
            background: #6c757d;
            color: white;
        }
        
        .btn-secondary:hover {
            background: #5a6268;
        }
        
        .btn-sm {
            padding: 5px 12px;
            font-size: 12px;
        }
        
        /* FORMULARIOS */
        .form-label {
            font-weight: 600;
            color: #333;
            margin-bottom: 8px;
        }
        
        .form-control, .form-select {
            border: 2px solid #e0e0e0;
            border-radius: 5px;
            padding: 10px;
            transition: all 0.3s;
        }
        
        .form-control:focus, .form-select:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 0.2rem rgba(102, 126, 234, 0.25);
        }
        
        /* TABLAS */
        .table {
            background: white;
        }
        
        .table thead {
            background: #f8f9fa;
            border-bottom: 2px solid #ddd;
        }
        
        .table th {
            font-weight: 600;
            color: #333;
            border: none;
        }
        
        .table tbody tr {
            border-bottom: 1px solid #eee;
            transition: background 0.3s;
        }
        
        .table tbody tr:hover {
            background: #f8f9fa;
        }
        
        .badge {
            border-radius: 20px;
            padding: 5px 12px;
            font-weight: 600;
        }
        
        .badge-estado-pendiente {
            background: #ffc107;
            color: #333;
        }
        
        .badge-estado-confirmada {
            background: #28a745;
            color: white;
        }
        
        .badge-estado-cancelada {
            background: #dc3545;
            color: white;
        }
        
        .badge-estado-completada {
            background: #17a2b8;
            color: white;
        }
        
        /* ALERTAS */
        .alert {
            border: none;
            border-radius: 8px;
            border-left: 4px solid;
            margin-bottom: 20px;
        }
        
        .alert-success {
            border-left-color: #28a745;
            background: #f0f7f4;
            color: #155724;
        }
        
        .alert-danger {
            border-left-color: #dc3545;
            background: #fdf7f7;
            color: #721c24;
        }
        
        .alert-warning {
            border-left-color: #ffc107;
            background: #fffbf0;
            color: #856404;
        }
        
        .alert-info {
            border-left-color: #17a2b8;
            background: #f0f7ff;
            color: #0c5460;
        }
        
        /* FOOTER */
        footer {
            background: #333;
            color: #999;
            text-align: center;
            padding: 30px 20px;
            margin-top: 40px;
        }
        
        footer a {
            color: #bbb;
            text-decoration: none;
        }
        
        footer a:hover {
            color: white;
        }
        
        /* UTILIDADES */
        .text-muted {
            color: #999 !important;
        }
        
        .mb-20 {
            margin-bottom: 20px;
        }
        
        .mt-20 {
            margin-top: 20px;
        }
        
        .no-data {
            text-align: center;
            padding: 40px 20px;
            color: #999;
        }
        
        .no-data i {
            font-size: 48px;
            margin-bottom: 10px;
            opacity: 0.5;
        }
        
        /* RESPONSIVE */
        @media (max-width: 768px) {
            main {
                padding: 20px 10px;
            }
            
            .navbar-brand {
                font-size: 18px;
                margin-right: 10px;
            }
            
            .nav-link {
                margin: 5px 0;
            }
            
            .table {
                font-size: 12px;
            }
            
            .user-menu {
                flex-direction: column;
                align-items: flex-start;
                gap: 10px;
            }
        }
    </style>
    <?php if (isset($estilos_adicionales)): ?>
        <?php echo $estilos_adicionales; ?>
    <?php endif; ?>
</head>
<body>
    <!-- HEADER -->
    <header>
        <nav class="navbar navbar-expand-lg">
            <div class="container">
                <a class="navbar-brand" href="index.php">
                    <i class="bi bi-scissors"></i> <?php echo APP_NAME; ?>
                </a>
                
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                    <span class="navbar-toggler-icon"></span>
                </button>
                
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav me-auto">
                        <?php if ($usuario_logueado): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="index.php">
                                    <i class="bi bi-house"></i> Inicio
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="reservas.php">
                                    <i class="bi bi-calendar-check"></i> Mis Reservas
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="nueva_reserva.php">
                                    <i class="bi bi-plus-circle"></i> Nueva Reserva
                                </a>
                            </li>
                            
                            <?php if ($es_admin): ?>
                                <li class="nav-item dropdown">
                                    <a class="nav-link dropdown-toggle" href="#" id="adminMenu" role="button" data-bs-toggle="dropdown">
                                        <i class="bi bi-shield-lock"></i> Admin
                                    </a>
                                    <ul class="dropdown-menu" aria-labelledby="adminMenu">
                                        <li><a class="dropdown-item" href="admin/dashboard.php">Dashboard</a></li>
                                        <li><hr class="dropdown-divider"></li>
                                        <li><a class="dropdown-item" href="admin/usuarios.php">Usuarios</a></li>
                                        <li><a class="dropdown-item" href="admin/barberos.php">Barberos</a></li>
                                        <li><a class="dropdown-item" href="admin/servicios.php">Servicios</a></li>
                                        <li><a class="dropdown-item" href="admin/citas.php">Citas</a></li>
                                        <li><hr class="dropdown-divider"></li>
                                        <li><a class="dropdown-item" href="admin/configuracion.php">Configuración</a></li>
                                    </ul>
                                </li>
                            <?php endif; ?>
                        <?php endif; ?>
                    </ul>
                    
                    <div class="user-menu">
                        <?php if ($usuario_logueado): ?>
                            <div class="user-info">
                                <i class="bi bi-person-circle"></i>
                                <strong><?php echo $_SESSION['usuario_nombre']; ?></strong>
                            </div>
                            <a href="mi_perfil.php" class="btn btn-secondary btn-sm">
                                <i class="bi bi-gear"></i> Perfil
                            </a>
                            <a href="logout.php" class="btn-logout">
                                <i class="bi bi-box-arrow-right"></i> Salir
                            </a>
                        <?php else: ?>
                            <a href="login.php" class="btn-logout">
                                <i class="bi bi-box-arrow-in-right"></i> Iniciar Sesión
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </nav>
    </header>
    
    <!-- MAIN CONTENT -->
    <main>
        <div class="container">
            <?php echo mostrar_mensaje(); ?>
            <?php echo $contenido; ?>
        </div>
    </main>
    
    <!-- FOOTER -->
    <footer>
        <p>&copy; 2026 <?php echo APP_NAME; ?> - Todos los derechos reservados</p>
        <small>Proyecto Final de Curso - Desarrollo Web</small>
    </footer>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/flatpickr@4.6.13/dist/flatpickr.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/flatpickr@4.6.13/dist/l10n/es.js"></script>
    <?php if (isset($scripts_adicionales)): ?>
        <?php echo $scripts_adicionales; ?>
    <?php endif; ?>
</body>
</html>
