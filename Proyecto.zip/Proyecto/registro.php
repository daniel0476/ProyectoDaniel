<?php
/**
 * registro.php
 * Registro de nuevos usuarios
 */

require_once 'config.php';
require_once 'funciones.php';

$titulo_pagina = 'Registro - ' . APP_NAME;

// Si ya está logueado, redirigir
if ($usuario_logueado) {
    header('Location: index.php');
    exit;
}

$error = '';
$exito = '';

// Procesar registro
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = trim($_POST['nombre'] ?? '');
    $apellidos = trim($_POST['apellidos'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $telefono = trim($_POST['telefono'] ?? '');
    $contrasena = trim($_POST['contrasena'] ?? '');
    $contrasena_confirmar = trim($_POST['contrasena_confirmar'] ?? '');
    
    // Validar datos
    if (empty($nombre) || empty($apellidos) || empty($email) || empty($contrasena)) {
        $error = 'Por favor, completa todos los campos requeridos.';
    } elseif (!validar_email($email)) {
        $error = 'El email no es válido.';
    } elseif (strlen($contrasena) < 6) {
        $error = 'La contraseña debe tener al menos 6 caracteres.';
    } elseif ($contrasena !== $contrasena_confirmar) {
        $error = 'Las contraseñas no coinciden.';
    } else {
        // Verificar que el email no existe
        $email_prep = escapar($email, $mysqli);
        $query_check = "SELECT ID_usuario FROM usuarios WHERE email = '$email_prep'";
        $resultado = $mysqli->query($query_check);
        
        if ($resultado->num_rows > 0) {
            $error = 'El email ya está registrado. <a href="login.php">¿Inicia sesión aquí?</a>';
        } else {
            // Registrar nuevo usuario
            $nombre_prep = escapar($nombre, $mysqli);
            $apellidos_prep = escapar($apellidos, $mysqli);
            $telefono_prep = escapar($telefono, $mysqli);
            $hash_contrasena = hashear_contrasena($contrasena);
            
            $query = "INSERT INTO usuarios (nombre, apellidos, email, telefono, contrasena, rol) 
                      VALUES ('$nombre_prep', '$apellidos_prep', '$email_prep', '$telefono_prep', '$hash_contrasena', 'cliente')";
            
            if ($mysqli->query($query)) {
                // Automáticamente loguearse
                $usuario_nuevo = obtener_usuario_por_email($email, $mysqli);
                
                $_SESSION['usuario_id'] = $usuario_nuevo['ID_usuario'];
                $_SESSION['usuario_nombre'] = $usuario_nuevo['nombre'];
                $_SESSION['usuario_email'] = $usuario_nuevo['email'];
                $_SESSION['usuario_rol'] = $usuario_nuevo['rol'];
                
                registrar_acceso($usuario_nuevo['ID_usuario'], $mysqli);
                
                redirigir_con_mensaje('index.php', '✅ ¡Bienvenido! Tu cuenta ha sido creada exitosamente.', 'success');
            } else {
                $error = 'Error al registrar: ' . $mysqli->error;
            }
        }
    }
}

ob_start();
?>

<div class="row">
    <div class="col-md-6 offset-md-3">
        <div class="card">
            <div class="card-header" style="text-align: center; padding: 30px 20px;">
                <h2 style="margin: 0; color: white;">
                    <i class="bi bi-person-plus"></i> Crear Cuenta
                </h2>
                <p style="margin-top: 10px; margin-bottom: 0; opacity: 0.95;">
                    Únete a nuestros clientes satisfechos
                </p>
            </div>
            <div class="card-body">
                <?php if (!empty($error)): ?>
                    <div class="alert alert-danger"><?php echo $error; ?></div>
                <?php endif; ?>
                
                <form method="POST" action="registro.php">
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="nombre" class="form-label">Nombre *</label>
                            <input 
                                type="text" 
                                class="form-control" 
                                id="nombre" 
                                name="nombre" 
                                required
                                value="<?php echo $_POST['nombre'] ?? ''; ?>"
                            >
                        </div>
                        
                        <div class="col-md-6">
                            <label for="apellidos" class="form-label">Apellidos *</label>
                            <input 
                                type="text" 
                                class="form-control" 
                                id="apellidos" 
                                name="apellidos" 
                                required
                                value="<?php echo $_POST['apellidos'] ?? ''; ?>"
                            >
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="email" class="form-label">Email *</label>
                        <input 
                            type="email" 
                            class="form-control" 
                            id="email" 
                            name="email" 
                            placeholder="tu@email.com"
                            required
                            value="<?php echo $_POST['email'] ?? ''; ?>"
                        >
                    </div>
                    
                    <div class="mb-3">
                        <label for="telefono" class="form-label">Teléfono</label>
                        <input 
                            type="tel" 
                            class="form-control" 
                            id="telefono" 
                            name="telefono"
                            value="<?php echo $_POST['telefono'] ?? ''; ?>"
                        >
                    </div>
                    
                    <div class="mb-3">
                        <label for="contrasena" class="form-label">Contraseña *</label>
                        <input 
                            type="password" 
                            class="form-control" 
                            id="contrasena" 
                            name="contrasena" 
                            placeholder="Mínimo 6 caracteres"
                            required
                        >
                        <small class="text-muted">Usa mayúsculas, minúsculas y números para mayor seguridad</small>
                    </div>
                    
                    <div class="mb-3">
                        <label for="contrasena_confirmar" class="form-label">Confirmar Contraseña *</label>
                        <input 
                            type="password" 
                            class="form-control" 
                            id="contrasena_confirmar" 
                            name="contrasena_confirmar" 
                            placeholder="Escribe la contraseña de nuevo"
                            required
                        >
                    </div>
                    
                    <div class="mb-3">
                        <div class="form-check">
                            <input 
                                class="form-check-input" 
                                type="checkbox" 
                                id="terminos" 
                                required
                            >
                            <label class="form-check-label" for="terminos">
                                Acepto los <a href="#" target="_blank">términos y condiciones</a> *
                            </label>
                        </div>
                    </div>
                    
                    <button type="submit" class="btn btn-primary w-100 mb-3">
                        <i class="bi bi-person-check"></i> Crear Cuenta
                    </button>
                </form>
                
                <div style="text-align: center; padding-top: 15px; border-top: 1px solid #eee;">
                    <p style="margin-bottom: 0;">¿Ya tienes cuenta? 
                        <a href="login.php" style="color: #667eea; font-weight: bold; text-decoration: none;">
                            Inicia sesión aquí
                        </a>
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
$contenido = ob_get_clean();
$estilos_adicionales = '<style>
    body {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    }
</style>';
include 'plantilla.php';
?>
