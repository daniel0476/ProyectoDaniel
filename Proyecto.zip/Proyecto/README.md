# 🔧 PROYECTO BARBERÍA - Sistema de Reservas Online

## 📋 Descripción

Sistema completo de gestión y reservas para una barbería, desarrollado con **PHP 8.2 + MySQL + Bootstrap 5**. Permite a los clientes reservar citas online y a los administradores gestionar el negocio de forma integral.

---

## 🎯 Características Principales

### 👥 Para Clientes
- ✅ Registro e inicio de sesión seguro
- ✅ Sistema de reservas con calendario
- ✅ Selección de barbero, servicio, fecha y hora
- ✅ Historial de citas
- ✅ Cancelación de citas (hasta 24h antes)
- ✅ Edición de perfil
- ✅ Sistema de idioma/traducción (extensible)

### 🛠️ Para Administradores
- ✅ **Dashboard** con estadísticas en tiempo real
- ✅ **CRUD Usuarios**: crear, editar, eliminar clientes
- ✅ **CRUD Barberos**: gestión de profesionales con horarios
- ✅ **CRUD Servicios**: crear servicios con precios y duraciones
- ✅ **CRUD Citas**: confirmar, completar o cancelar citas
- ✅ **Configuración del sistema**: horarios, precios, ajustes generales

### 🔐 Seguridad
- ✅ Autenticación segura con contraseñas hasheadas (bcrypt)
- ✅ Control de sesiones con timeout
- ✅ Validación de datos en servidor y cliente
- ✅ Protección XSS y SQL Injection
- ✅ Roles de usuario (cliente/admin)

---

## 🚀 Instalación

### Requisitos
- **PHP 8.0+** (recomendado 8.2)
- **MySQL 5.7+** o **MariaDB 10.3+**
- **Apache** o servidor web compatible
- **Composer** (opcional, si usas librerías)

### Pasos de Instalación

#### 1. Descargar el Proyecto
```bash
cd c:\Users\Usuario\Desktop\Proyecto
```

#### 2. Crear Base de Datos
```bash
# Opción A: Usar phpMyAdmin
# - Acceder a http://localhost/phpmyadmin
# - Crear nueva BD: "barberia"
# - Importar el archivo: base_de_datos/barberia_mejorada.sql

# Opción B: Usar línea de comandos MySQL
mysql -u root -p -e "CREATE DATABASE IF NOT EXISTS barberia CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;"
mysql -u root -p barberia < base_de_datos/barberia_mejorada.sql
```

#### 3. Configurar Conexión a BD
Editar el archivo `config.php`:

```php
define('DB_HOST', 'localhost');      // Tu host
define('DB_USER', 'root');           // Tu usuario MySQL
define('DB_PASS', '');               // Tu contraseña (vacío si no tienes)
define('DB_NAME', 'barberia');       // Nombre de la BD
```

#### 4. Colocar Proyecto en Servidor Web
```bash
# Para XAMPP/WAMP:
# Copiar la carpeta al directorio htdocs o www
# C:\xampp\htdocs\barberia\
# o
# C:\wamp\www\barberia\
```

#### 5. Acceder a la Aplicación
```
http://localhost/barberia/
```

---

## 📱 Estructura de Carpetas

```
Proyecto/
│
├── config.php                 # Configuración y conexión BD
├── funciones.php             # Funciones reutilizables
├── plantilla.php             # Template HTML base
│
├── login.php                 # Login de usuarios
├── registro.php              # Registro de nuevos clientes
├── logout.php                # Cerrar sesión
│
├── index.php                 # Página principal
├── nueva_reserva.php         # Sistema de reservas
├── reservas.php              # Ver mis citas
├── mi_perfil.php            # Editar perfil de usuario
│
├── admin/                    # Carpeta administración
│   ├── dashboard.php         # Panel de control
│   ├── usuarios.php          # Gestión de clientes
│   ├── barberos.php          # Gestión de barberos
│   ├── servicios.php         # Gestión de servicios
│   ├── citas.php             # Gestión de citas
│   └── configuracion.php     # Ajustes del sistema
│
├── base_de_datos/
│   ├── barberia.sql          # BD original
│   └── barberia_mejorada.sql # BD optimizada (USAR ESTA)
│
└── ejemplo_Diseño_Pagina/   # Diseños de referencia (opcional)
```

---

## 🔑 Credenciales por Defecto

### Usuario Cliente
```
Email: juan@email.com
Contraseña: 1234
```

### Usuario Administrador
```
Email: admin@email.com
Contraseña: 1234
```

⚠️ **IMPORTANTE**: Cambiar estas credenciales en producción.

---

## 📊 Base de Datos

### Tablas Principales

| Tabla | Descripción |
|-------|-------------|
| `usuarios` | Clientes registrados |
| `barberos` | Personal de la barbería |
| `servicios` | Servicios ofrecidos |
| `citas` | Reservas de clientes |
| `horarios_disponibles` | Bloques de tiempo disponible |
| `configuracion_sistema` | Ajustes generales |
| `historial_acceso` | Log de accesos (auditoría) |

### Relaciones principales
- Usuario → Muchas citas
- Barbero → Muchas citas
- Servicio → Muchas citas
- Cita → Un usuario, un barbero, un servicio

---

## 🎨 Navegación

### Menú Cliente (Logueado)
```
Inicio → Status de citas y servicios
Mis Reservas → Historial y cancellations
Nueva Reserva → Crear cita con calendario
Mi Perfil → Editar datos personales
```

### Menú Admin (Solo Administrador)
```
Dashboard → Estadísticas en tiempo real
Usuarios → CRUD de clientes
Barberos → CRUD de profesionales
Servicios → CRUD de servicios
Citas → Gestión de reservas
Configuración → Ajustes del sistema
```

---

## 🔧 Configuración Recomendada

### Horarios
- **Apertura**: 09:00
- **Cierre**: 18:00
- **Duración slot**: 30 minutos
- **Tiempo preparación**: 5 minutos

### Servicios Iniciales
1. Corte de pelo - €12 - 30 min
2. Corte degradado - €15 - 45 min
3. Arreglo de barba - €8 - 20 min
4. Afeitado clásico - €10 - 25 min

### Barberos Ejemplo
1. Carlos Gómez - Cortes degradados - 8 años
2. Miguel López - Barba y estilos - 5 años

---

## 💡 Workflow de Reserva

### Cliente
1. **Registrarse** → llenar formulario
2. **Iniciar sesión** → con email/contraseña
3. **Nueva Reserva** → seleccionar servicio
4. **Elegir Barbero** → ver especialidad y horarios
5. **Seleccionar Fecha/Hora** → calendario con slots disponibles
6. **Confirmar** → la cita queda PENDIENTE
7. **Esperar confirmación** → barbero confirma o rechaza

### Admin
1. **Login Admin** → acceder a dashboard
2. **Ver Citas Pendientes** → en panel de control
3. **Confirmar o Rechazar** → cambiar estado de cita
4. **Marcar Completada** → cuando termine
5. **Generar Reportes** → ver ingresos y estadísticas

---

## 🧪 Testing / Pruebas

### Escenarios de Prueba

#### Test 1: Registro y Login
```
1. Ir a /registro.php
2. Crear nueva cuenta
3. Verificar que se autologuea
4. Ir a /logout.php
5. Verificar logout
6. Login con credenciales
```

#### Test 2: Sistema de Reservas
```
1. Cliente logueado
2. Click "Nueva Reserva"
3. Seleccionar servicio
4. Elegir barbero
5. Seleccionar fecha (hoy o futura)
6. Seleccionar hora disponible
7. Confirmar
8. Verificar en "Mis Reservas"
```

#### Test 3: Admin Panel
```
1. Login como admin@email.com
2. Acceder a /admin/dashboard.php
3. Ver estadísticas
4. Ir a /admin/usuarios.php
5. Ver lista de clientes
6. Ir a /admin/citas.php
7. Cambiar estado de cita
8. Ir a /admin/configuracion.php
9. Actualizar horarios
```

---

## 🆘 Solución de Problemas

### Error: "Error de conexión: Access denied for user 'root'@'localhost'"
**Solución**: Verificar credenciales en `config.php`
```php
define('DB_USER', 'tu_usuario_real');
define('DB_PASS', 'tu_contraseña_real');
```

### Error: "1205 - Lock wait timeout exceeded"
**Solución**: Reiniciar servidor MySQL

### Error: "Undefined variable: contenido" en plantilla.php
**Solución**: Asegurarse que todos los archivos hagan `ob_start()` antes de incluir plantilla

### Las citas no se guardan
**Solución**: Verificar que la carpeta tiene permisos de escritura (755)

### Contraseña incorrecta después de registro
**Solución**: Las contraseñas están hasheadas. Si necesitas resetear:
```sql
UPDATE usuarios SET contrasena = '$2y$10$...' WHERE email = 'test@test.com';
```

---

## 📈 Mejoras Futuras (Roadmap)

### Fase 2
- [ ] Envío de emails de confirmación
- [ ] SMS de recordatorio de citas
- [ ] Sistema de pagos online (Stripe/PayPal)
- [ ] API REST para aplicación móvil
- [ ] Reportes avanzados (PDF, Excel)

### Fase 3
- [ ] Multi-idioma (i18n/l10n)
- [ ] Sistema de reseñas y valoraciones
- [ ] Programa de fidelización/puntos
- [ ] Integración con Google Calendar
- [ ] Dashboard móvil responsivo mejorado

### Fase 4
- [ ] Chat en vivo con soporte
- [ ] Integración redes sociales (login)
- [ ] Promociones y cupones descuento
- [ ] Análisis avanzado de negocio
- [ ] Sistema de turnos y cola virtual

---

## 📞 Soporte y Documentación

### Archivos Útiles

| Archivo | Descripción |
|---------|-------------|
| `config.php` | Configuración principal |
| `funciones.php` | Funciones reutilizables |
| `barberia_mejorada.sql` | BD con todas las tablas |

### Recursos Externos
- [Documentación PHP](https://www.php.net/manual/es/)
- [Documentación MySQL](https://dev.mysql.com/doc/)
- [Bootstrap 5](https://getbootstrap.com/docs/5.3/)
- [SPA phpMyAdmin](https://www.phpmyadmin.net/)

---

## 📝 Notas Importantes

1. **Seguridad**: En producción, cambiar `DB_PASS` y usar HTTPS
2. **Respaldos**: Hacer backup regular de `barberia.sql`
3. **Updates PHP**: Usar PHP 8.2+ para máxima seguridad
4. **Validación**: Todos los formularios validan en servidor
5. **Logs**: Revisar archivo `historial_acceso` para auditoría

---

## 👨‍💻 Autor

Proyecto Final de Curso - 2DAW DWEC  
Desarrollado como demostración de competencias en PHP, MySQL y frontends Web.

---

## 📄 Licencia

Este proyecto es para uso educativo.

---

## ✅ Conclusión

¡Tu sistema de barbería está listo! 🎉

Para comenzar:
1. Configura la BD (barberia_mejorada.sql)
2. Ajusta credenciales en config.php
3. ¡Accede a http://localhost/barberia/
4. Prueba con las credenciales por defecto

¿Preguntas? Revisa la sección **Solución de Problemas**.

**Happy Coding! 💪**
